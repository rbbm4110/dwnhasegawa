'use strict'

class SuperNaming {　　　//←スーパークラス
  　constructor() {　  
  　　this.name = "田中";
  　}
  　outputName() {　　　  
  　　return this.name;
  　}
  }
  
  class SubGreeting extends SuperNaming {　  //←サブクラス
  　outputName() {
  　　return super.outputName() + "太郎";　　//←メソッドの上書き
  　}
  　outputHello() {　　　　　//←メソッドの追加
  　　console.log("Hello!!");
  　}
  }
  
  const Naming = new SuperNaming
  const Greeting = new SubGreeting
  
  console.log(`${Greeting.outputHello()} `)